#include <stdio.h>
#include <stdlib.h>
#include "Structures.h"
#include "Define.h"

typedef struct GrandeCommande {
	Commande *TableauDesCommandes;		
	int NombreDeCommande;				
} GrandeCommande;

typedef struct panier{
	Commande TableauDesCommandes[MAX_COMMANDES];		
	int NombreDeCommande;
}panier;

GrandeCommande AllCommandes; // Contient toutes les commandes des 4h
panier Panier; // Contient toutes les commandes effectu�s par un client durant son achat

/*Cette fonction est activ�e � chaque d�but de fuseaux des 4h, elle permet de cr�er un tableau dans lequel sera contenu toutes les commandes effectu�es durant 4h.*/
int init_tableau_commandes(CommandeFile *AllCommandes) {
	void* Ptr = (void*)malloc(MAX_COMMANDES * sizeof(Commande));
	if (Ptr != NULL) {
		AllCommandes->TableauDesCommandes[MAX_COMMANDES];
		AllCommandes->NombreDeCommande = 0;
		return OK;
	}
	else return ERROR;
}

/*Cette fonction est activ�e lors de la connexion du client, elle permet d'initialiser le Panier dans lequel sera disposer ses commandes �ventuels.*/
int init_panier(CommandeFile *Panier) {
	
	void* Ptr = (void*)malloc(MAX_COMMANDES * sizeof(Commande));
	if (Ptr != NULL) {
		Panier->TableauDesCommandes[MAX_COMMANDES];
		Panier->NombreDeCommande = 0;
		return OK;
	}
	else return ERROR;
}

/*Cette fonction permet d'ajouter une nouvelle commande au Panier du client.*/
int ajout_panier(CommandeFile *Panier, int ID_article, int quantite, int ID_client) {
		
	// Cr�ation d'une nouvelle commande
	Commande nouvelarticle;
	nouvelarticle.ArticleID = ID_article;
	nouvelarticle.ClientID = ID_client;
	nouvelarticle.Quantity = quantite;
	nouvelarticle.CodeRetrait = rand() % 10000;

	// Ajout de la commande au Panier
	Panier->TableauDesCommandes[Panier->NombreDeCommande] = nouvelarticle;
	(Panier->NombreDeCommande)++;
	return OK;
}

/* Cette fonction permet de supprimer une commande du Panier*/
int supprimer_dans_panier(CommandeFile *Panier, int indice) {
	for (int i = indice -1; i <MAX_COMMANDES-1; i++) {
		Panier->TableauDesCommandes[i] = Panier->TableauDesCommandes[i+1];
	}
	Panier->TableauDesCommandes[MAX_COMMANDES - 1].ArticleID = NULL;
	Panier->TableauDesCommandes[MAX_COMMANDES - 1].ClientID = NULL;
	Panier->TableauDesCommandes[MAX_COMMANDES - 1].Quantity = NULL;
	Panier->TableauDesCommandes[MAX_COMMANDES - 1].CodeRetrait = NULL;
	Panier->NombreDeCommande--;
	return OK;
}

/* Cette fonction permet de valider la totalit� du Panier, les commandes seront alors d�finitives.*/
int validation_panier(CommandeFile* AllCommandes, CommandeFile* Panier) {

	//Ajout du Panier au tableau de toutes les commandes des 4h
	int nb = AllCommandes->NombreDeCommande;
	for (int indice = 0; indice < Panier->NombreDeCommande; indice++) {
		AllCommandes->TableauDesCommandes[nb+indice] = Panier->TableauDesCommandes[indice];
		AllCommandes->NombreDeCommande++;
	}

	// Mise � 0 du Panier
	init_panier(Panier);
	return 1;
}

/*Cette fonction sera activ�e au bout des fuseaux de 4h elle permettra de mettre � 0 le fichier vente et de sauvegarder
les commandes de ces 4 derni�res heures dans celui-ci.*/
int envoi_commandes(CommandeFile *AllCommandes, char nom_fichier[]) {

		FILE *fic_rep;					/* le fichier */

		if ((fopen_s(&fic_rep, nom_fichier, "w")) != 0) {
			// Ouverture du fichier poss�dant le nom compris dans nom_fichier si il existe sinon cr�ation d'un fichier poss�dant ce nom
			// Mode d'utilisation "w" = write (�crire uniquement)
			// Si la fonction fopen_s renvoie autre chose que 0 cela signifie qu'elle n'a pas fonctionn�e
			return(ERROR);
		}
		else { // si la fonction fopen_s a fonctionn�e
			for (int i = 0; i < AllCommandes->NombreDeCommande; i++) {
				fprintf_s(fic_rep, "%d;%d;%d;%d\n", AllCommandes->TableauDesCommandes->ClientID, AllCommandes->TableauDesCommandes->ArticleID, AllCommandes->TableauDesCommandes->Quantity,AllCommandes->TableauDesCommandes->CodeRetrait);
				// on affiche dans le fichier chaque �l�ment de toutes les commandes
			}
			fclose(fic_rep); // On ferme le fichier qui a �t� ouvert
			return(OK);
		}

}

int main() {
	init_panier( &Panier );
	printf("il y a %d nombre de commandes \n", Panier.NombreDeCommande);
	ajout_panier(&Panier, 71, 4, 0111);
	ajout_panier(&Panier, 21, 5, 0131);
	ajout_panier(&Panier, 31, 6, 0171);
	ajout_panier(&Panier, 11, 7, 0221);
	supprimer_dans_panier(&Panier, 4);
	printf("maintenant il y a %d commandes \n", Panier.NombreDeCommande);
	for (int i = 0; i < Panier.NombreDeCommande; i++) {
		printf("article numero %d \n", Panier.TableauDesCommandes[i].ArticleID);
	}
	validation_panier(&AllCommandes,&Panier);
	printf("il y a %d nombre de commandes \n", Panier.NombreDeCommande);
	printf("il y a %d nombre de commandes valid�es \n", AllCommandes.NombreDeCommande);
	ajout_panier(&Panier, 11, 12, 0171);
	ajout_panier(&Panier, 201, 8, 1121);
	printf("il y a %d nombre de commandes \n", Panier.NombreDeCommande);
	validation_panier(&AllCommandes, &Panier);
	printf("il y a %d nombre de commandes valid�es \n", AllCommandes.NombreDeCommande);
	for (int i = 0; i < AllCommandes.NombreDeCommande; i++) {
		printf("article numero %d \n", AllCommandes.TableauDesCommandes[i].ArticleID);
	}
	envoi_commandes(&AllCommandes, "trololo");
	system("pause");
}