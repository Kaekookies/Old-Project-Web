var http = require('http');
var fs = require('fs');
var url = require('url');
var page;
/* Chargement du fichier main.html affiché au client */
var server = http.createServer(function(req, res) { //creation du serveur en local
    page = url.parse(req.url).pathname;
    if (page == '/'){
        fs.readFile('./connexion.html', 'utf-8', function(error, content) {
            res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
            res.end(content);
        });
    }
    else if (page == '/Inscription.html'){
        fs.readFile('./Inscription.html', 'utf-8', function(error, content) {
            res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
            res.end(content);
        });
    }
    else if (page =='/Achat.html'){
        fs.readFile('./Achat.html', 'utf-8', function(error, content) {
            res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
            res.end(content);
        })}
    else if (page =='/Aile.html'){
        fs.readFile('./Aile.html', 'utf-8', function(error, content) {
            res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
            res.end(content);
        })
        }
        else if(page =='/Concombre.html'){
            fs.readFile('./Concombre.html', 'utf-8', function(error, content) {
                res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
                res.end(content);
            })
            }
        else if(page == '/Salade.html'){
                    fs.readFile('./Salade.html', 'utf-8', function(error, content) {
                        res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
                        res.end(content);
                    })
                }
        else if(page == '/Porte.html'){
                    fs.readFile('./Porte.html', 'utf-8', function(error, content) {
                        res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
                        res.end(content);
                    })
                    }
        else if(page == '/Pate.html'){
                            fs.readFile('./Pate.html', 'utf-8', function(error, content) {
                                res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
                                res.end(content);
                        })
                    }
        else if(page == '/Autruche.html'){
                        fs.readFile('./Autruche.html', 'utf-8', function(error, content) {
                            res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
                            res.end(content);
                    })
                }
               else if (page == '/connexion.html'){
                    fs.readFile('./connexion.html', 'utf-8', function(error, content) {
                        res.writeHead(200, {"Content-Type": "text/html"}); //on fait en sorte que le serveur comprenne le html
                        res.end(content);
                    });
                }
});



/* Chargement de socket.io, qui permet la communication en temps réel par "messages"*/
var io = require('socket.io').listen(server);

/* Begin of synchronous listening of server */
io.sockets.on('connection', function (socket) {


    socket.on('executeHelloC', function (message) { //socket de test pour voir s'il était bien possible d'appeler des fonctions en c avec du js
      console.log(message);

      fs.writeFileSync("testWrite.txt", message+";" , "UTF-8");

      var exec = require('child_process').exec;

      var cmd = 'Hello.exe';
      //var path = '';
      var child = exec(cmd, function(error, stdout, stderr) {
        if (error === null) {
            console.log(stdout);
            console.log('success');
        } else {
            console.log('error');
        }
      });
    });

    socket.on('executeconnect', function (message) { //on execute ce que le côté client nous a demandé
        console.log(message);
        fs.writeFileSync("connect.txt", message , "UTF-8"); //ecriture dans un .txt qu'on envoie pour le code c
        
        var exec = require('child_process').exec;
        var cmd = 'GenerationExe.exe'; 
        //var path = '';
        var child = exec(cmd, function(error, stdout, stderr) {//appel de la fonction en c
        var fs = require("fs"); 
        var contenu;
        contenu = fs.readFileSync("reponse.txt", "UTF-8"); //on lit le fichier réponse, et on stocke ce qu'on a lu dans une variable
        socket.emit('message', contenu);  //on envoie le contenu du message au client 
          if (error === null) {
              console.log(stdout); //verification si le code s'est lancé ou non
              console.log('success');
          } else {
              console.log('error');
          }
        });
      });

});
socket.on('Apoulet', function (message) { //socket de test pour voir s'il était bien possible d'appeler des fonctions en c avec du js
fs.writeFileSync("achat.txt","001;"+ message+";" , "UTF-8");
});
socket.on('Autruche', function (message) { //socket de test pour voir s'il était bien possible d'appeler des fonctions en c avec du js
fs.writeFileSync("achat.txt","002;"+ message+";" , "UTF-8");
});
socket.on('Concombre', function (message) { //socket de test pour voir s'il était bien possible d'appeler des fonctions en c avec du js
fs.writeFileSync("achat.txt","003;"+ message+";" , "UTF-8");
});
socket.on('Salade', function (message) { //socket de test pour voir s'il était bien possible d'appeler des fonctions en c avec du js
fs.writeFileSync("achat.txt","004;"+ message+";" , "UTF-8");
});
socket.on('porte', function (message) { //socket de test pour voir s'il était bien possible d'appeler des fonctions en c avec du js
fs.writeFileSync("achat.txt","005;"+ message+";" , "UTF-8");
});
socket.on('Pate', function (message) { //socket de test pour voir s'il était bien possible d'appeler des fonctions en c avec du js
fs.writeFileSync("achat.txt","006;"+ message+";" , "UTF-8");
});

server.listen(8080); //on positionne le serveur en localhost à la position 8080
